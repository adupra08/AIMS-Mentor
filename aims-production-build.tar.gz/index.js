var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/services/opportunityMatcher.ts
var opportunityMatcher_exports = {};
__export(opportunityMatcher_exports, {
  categorizOpportunityByStudent: () => categorizOpportunityByStudent,
  getUpcomingOpportunities: () => getUpcomingOpportunities,
  matchOpportunities: () => matchOpportunities
});
function matchOpportunities(studentProfile, opportunities2) {
  const matches = [];
  const now = /* @__PURE__ */ new Date();
  for (const opportunity of opportunities2) {
    if (opportunity.deadline) {
      const deadline = new Date(opportunity.deadline);
      if (deadline <= now) {
        continue;
      }
    }
    let score = 0;
    const reasons = [];
    const eligibleGrades = opportunity.eligibleGrades;
    if (eligibleGrades && eligibleGrades.length > 0) {
      if (!eligibleGrades.includes(studentProfile.currentGrade)) {
        continue;
      }
      score += 10;
      reasons.push("Grade eligible");
    }
    const opportunitySubjects = opportunity.subjects || [];
    const studentInterests = [
      ...studentProfile.academicInterests || [],
      ...studentProfile.interestedSubjects || [],
      ...studentProfile.currentSubjects || []
    ];
    let subjectMatches = 0;
    for (const subject of opportunitySubjects) {
      if (studentInterests.some(
        (interest) => interest.toLowerCase().includes(subject.toLowerCase()) || subject.toLowerCase().includes(interest.toLowerCase())
      )) {
        subjectMatches++;
      }
    }
    if (subjectMatches > 0) {
      score += subjectMatches * 15;
      reasons.push(`Matches ${subjectMatches} of your interests: ${opportunitySubjects.slice(0, 2).join(", ")}`);
    }
    if (studentProfile.careerGoals && opportunity.description) {
      const careerGoals = studentProfile.careerGoals.toLowerCase();
      const description = opportunity.description.toLowerCase();
      if (careerGoals.includes("engineer") && (description.includes("engineering") || description.includes("stem"))) {
        score += 20;
        reasons.push("Aligns with engineering career goals");
      } else if (careerGoals.includes("research") && description.includes("research")) {
        score += 20;
        reasons.push("Matches research interests");
      } else if (careerGoals.includes("business") && (description.includes("business") || description.includes("leadership"))) {
        score += 15;
        reasons.push("Fits business/leadership aspirations");
      } else if (careerGoals.includes("medicine") && (description.includes("biology") || description.includes("health"))) {
        score += 20;
        reasons.push("Relevant to medical field interests");
      }
    }
    const dreamColleges = (studentProfile.dreamColleges || []).map((c) => c.toLowerCase());
    const tags = opportunity.tags || [];
    if (dreamColleges.some(
      (college) => college.includes("mit") || college.includes("stanford") || college.includes("harvard") || college.includes("caltech")
    )) {
      if (tags.includes("prestigious") || tags.includes("mit") || tags.includes("stanford") || tags.includes("harvard")) {
        score += 25;
        reasons.push("Prestigious program matching your dream colleges");
      }
    }
    if (studentProfile.currentGpa) {
      const gpa = parseFloat(studentProfile.currentGpa.toString());
      if (opportunity.difficultyLevel === "advanced" && gpa >= 3.7) {
        score += 15;
        reasons.push("Advanced program suitable for your high GPA");
      } else if (opportunity.difficultyLevel === "intermediate" && gpa >= 3.3) {
        score += 10;
        reasons.push("Well-matched difficulty level");
      } else if (opportunity.difficultyLevel === "beginner") {
        score += 5;
        reasons.push("Good starting opportunity");
      }
    }
    const currentTags = opportunity.tags || [];
    if (currentTags.includes("current") || currentTags.includes("now")) {
      score += 30;
      reasons.push("Currently accepting applications!");
    }
    if (opportunity.deadline) {
      const now2 = /* @__PURE__ */ new Date();
      const deadline = new Date(opportunity.deadline);
      const daysUntilDeadline = Math.ceil((deadline.getTime() - now2.getTime()) / (1e3 * 60 * 60 * 24));
      if (daysUntilDeadline > 0 && daysUntilDeadline <= 30) {
        score += 20;
        reasons.push(`Application deadline in ${daysUntilDeadline} days - apply soon!`);
      } else if (daysUntilDeadline > 30 && daysUntilDeadline <= 90) {
        score += 10;
        reasons.push(`Upcoming deadline: ${deadline.toLocaleDateString()}`);
      }
    }
    const extracurriculars = (studentProfile.extracurricularActivities || []).map((e) => e.toLowerCase());
    if (extracurriculars.some(
      (activity) => activity.includes("research") || activity.includes("science") || activity.includes("math") || activity.includes("coding")
    )) {
      if (opportunity.category === "research" || opportunity.category === "competition") {
        score += 10;
        reasons.push("Matches your extracurricular interests");
      }
    }
    if (score >= 15) {
      matches.push({
        opportunity,
        score,
        reasons: reasons.slice(0, 3)
        // Limit to top 3 reasons
      });
    }
  }
  return matches.sort((a, b) => b.score - a.score).slice(0, 10);
}
function getUpcomingOpportunities(opportunities2) {
  const now = /* @__PURE__ */ new Date();
  const nextMonths = /* @__PURE__ */ new Date();
  nextMonths.setMonth(now.getMonth() + 6);
  return opportunities2.filter((opp) => {
    if (!opp.deadline) {
      return true;
    }
    const deadline = new Date(opp.deadline);
    return deadline > now && deadline <= nextMonths;
  }).sort((a, b) => {
    if (!a.deadline && !b.deadline) return 0;
    if (!a.deadline) return 1;
    if (!b.deadline) return -1;
    return new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
  }).slice(0, 8);
}
function categorizOpportunityByStudent(opportunity, studentProfile) {
  const eligibleGrades = opportunity.eligibleGrades;
  const isGradeEligible = eligibleGrades && eligibleGrades.includes(studentProfile.currentGrade);
  if (!isGradeEligible) {
    return {
      category: "consider",
      reasoning: "Not currently grade-eligible, but good to keep in mind for future"
    };
  }
  const currentGpa = studentProfile.currentGpa ? parseFloat(studentProfile.currentGpa.toString()) : 0;
  const isAdvanced = opportunity.difficultyLevel === "advanced";
  const isPaid = opportunity.isPaid;
  if (isAdvanced && currentGpa >= 3.8) {
    return {
      category: "highly-recommended",
      reasoning: "Your strong academic record makes you a competitive candidate"
    };
  } else if (isAdvanced && currentGpa >= 3.5) {
    return {
      category: "stretch-goal",
      reasoning: "Challenging but achievable with your academic background"
    };
  } else if (!isAdvanced && currentGpa >= 3.3) {
    return {
      category: "highly-recommended",
      reasoning: "Well-matched to your current academic level"
    };
  } else {
    return {
      category: "good-match",
      reasoning: "Good opportunity to build experience and skills"
    };
  }
}
var init_opportunityMatcher = __esm({
  "server/services/opportunityMatcher.ts"() {
    "use strict";
  }
});

// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  academicPathwayRelations: () => academicPathwayRelations,
  academicPathways: () => academicPathways,
  achievementRelations: () => achievementRelations,
  achievements: () => achievements,
  chatMessageRelations: () => chatMessageRelations,
  chatMessages: () => chatMessages,
  graduationRequirementRelations: () => graduationRequirementRelations,
  graduationRequirements: () => graduationRequirements,
  insertAchievementSchema: () => insertAchievementSchema,
  insertChatMessageSchema: () => insertChatMessageSchema,
  insertGraduationRequirementSchema: () => insertGraduationRequirementSchema,
  insertStudentCourseProgressSchema: () => insertStudentCourseProgressSchema,
  insertStudentProfileSchema: () => insertStudentProfileSchema,
  insertTodoSchema: () => insertTodoSchema,
  opportunities: () => opportunities,
  opportunityRelations: () => opportunityRelations,
  progressTracking: () => progressTracking,
  progressTrackingRelations: () => progressTrackingRelations,
  sessions: () => sessions,
  studentCourseProgress: () => studentCourseProgress,
  studentCourseProgressRelations: () => studentCourseProgressRelations,
  studentOpportunities: () => studentOpportunities,
  studentOpportunityRelations: () => studentOpportunityRelations,
  studentProfileRelations: () => studentProfileRelations,
  studentProfiles: () => studentProfiles,
  todoRelations: () => todoRelations,
  todos: () => todos,
  users: () => users
});
import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  integer,
  boolean,
  serial,
  decimal
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
var sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull()
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);
var users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var studentProfiles = pgTable("student_profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  currentGrade: integer("current_grade").notNull(),
  currentGpa: decimal("current_gpa", { precision: 3, scale: 2 }),
  currentSubjects: jsonb("current_subjects").$type().default([]),
  interestedSubjects: jsonb("interested_subjects").$type().default([]),
  dreamColleges: jsonb("dream_colleges").$type().default([]),
  academicInterests: jsonb("academic_interests").$type().default([]),
  careerGoals: text("career_goals"),
  extracurricularActivities: jsonb("extracurricular_activities").$type().default([]),
  completedAPs: jsonb("completed_aps").$type().default([]),
  plannedAPs: jsonb("planned_aps").$type().default([]),
  testScores: jsonb("test_scores").$type().default({}),
  state: varchar("state"),
  location: varchar("location"),
  // City name
  schoolDistrict: varchar("school_district"),
  isOnboardingComplete: boolean("is_onboarding_complete").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var academicPathways = pgTable("academic_pathways", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => studentProfiles.id),
  pathwayData: jsonb("pathway_data").$type().notNull(),
  targetCollege: varchar("target_college").notNull(),
  overallProgress: decimal("overall_progress", { precision: 5, scale: 2 }).default("0"),
  lastUpdated: timestamp("last_updated").defaultNow(),
  createdAt: timestamp("created_at").defaultNow()
});
var opportunities = pgTable("opportunities", {
  id: serial("id").primaryKey(),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  category: varchar("category").notNull(),
  // competition, internship, volunteer, etc.
  eligibleGrades: jsonb("eligible_grades").$type().default([]),
  subjects: jsonb("subjects").$type().default([]),
  deadline: timestamp("deadline"),
  applicationUrl: varchar("application_url"),
  isTeamBased: boolean("is_team_based").default(false),
  location: varchar("location"),
  isPaid: boolean("is_paid").default(false),
  difficultyLevel: varchar("difficulty_level"),
  // beginner, intermediate, advanced
  tags: jsonb("tags").$type().default([]),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var studentOpportunities = pgTable("student_opportunities", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => studentProfiles.id),
  opportunityId: integer("opportunity_id").notNull().references(() => opportunities.id),
  status: varchar("status").default("bookmarked"),
  // bookmarked, applied, completed
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow()
});
var todos = pgTable("todos", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => studentProfiles.id),
  title: varchar("title").notNull(),
  description: text("description"),
  dueDate: timestamp("due_date"),
  priority: varchar("priority").default("medium"),
  // low, medium, high
  category: varchar("category"),
  // study, application, extracurricular, etc.
  isCompleted: boolean("is_completed").default(false),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => studentProfiles.id),
  message: text("message").notNull(),
  sender: varchar("sender").notNull(),
  // user, ai
  response: text("response"),
  createdAt: timestamp("created_at").defaultNow()
});
var progressTracking = pgTable("progress_tracking", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => studentProfiles.id),
  category: varchar("category").notNull(),
  // academic, extracurricular, test_prep, overall
  score: decimal("score", { precision: 5, scale: 2 }).notNull(),
  details: jsonb("details").default({}),
  recordedAt: timestamp("recorded_at").defaultNow()
});
var achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => studentProfiles.id),
  title: varchar("title").notNull(),
  description: text("description"),
  type: varchar("type").notNull(),
  // competition, research, certification, award, other
  category: varchar("category"),
  // academic, extracurricular, leadership, technical
  dateAchieved: timestamp("date_achieved"),
  organization: varchar("organization"),
  // e.g., "Google", "Science Fair", "MIT"
  location: varchar("location"),
  // where the achievement occurred
  ranking: varchar("ranking"),
  // e.g., "1st Place", "Finalist", "Honorable Mention"
  certificateUrl: varchar("certificate_url"),
  // link to certificate/proof
  publicationUrl: varchar("publication_url"),
  // for research papers
  skills: jsonb("skills").$type().default([]),
  // related skills
  isVerified: boolean("is_verified").default(false),
  verificationNotes: text("verification_notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var graduationRequirements = pgTable("graduation_requirements", {
  id: serial("id").primaryKey(),
  state: text("state").notNull(),
  district: text("district"),
  subject: text("subject").notNull(),
  courseTitle: text("course_title").notNull(),
  creditsRequired: decimal("credits_required", { precision: 3, scale: 1 }).notNull(),
  isMandatory: boolean("is_mandatory").default(true).notNull(),
  gradeLevel: text("grade_level"),
  // e.g., "9-12", "11-12"
  description: text("description"),
  alternatives: text("alternatives").array(),
  // Alternative courses that fulfill requirement
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var studentCourseProgress = pgTable("student_course_progress", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => studentProfiles.id),
  requirementId: integer("requirement_id").references(() => graduationRequirements.id),
  courseName: text("course_name").notNull(),
  creditsEarned: decimal("credits_earned", { precision: 3, scale: 1 }).notNull(),
  grade: text("grade"),
  // A, B, C, D, F
  semester: text("semester"),
  // Fall 2024, Spring 2025
  isCompleted: boolean("is_completed").default(false).notNull(),
  plannedSemester: text("planned_semester"),
  // For future courses
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var studentProfileRelations = relations(studentProfiles, ({ one, many }) => ({
  user: one(users, {
    fields: [studentProfiles.userId],
    references: [users.id]
  }),
  pathways: many(academicPathways),
  opportunities: many(studentOpportunities),
  todos: many(todos),
  chatMessages: many(chatMessages),
  progressRecords: many(progressTracking),
  achievements: many(achievements),
  courseProgress: many(studentCourseProgress)
}));
var academicPathwayRelations = relations(academicPathways, ({ one }) => ({
  student: one(studentProfiles, {
    fields: [academicPathways.studentId],
    references: [studentProfiles.id]
  })
}));
var opportunityRelations = relations(opportunities, ({ many }) => ({
  studentOpportunities: many(studentOpportunities)
}));
var studentOpportunityRelations = relations(studentOpportunities, ({ one }) => ({
  student: one(studentProfiles, {
    fields: [studentOpportunities.studentId],
    references: [studentProfiles.id]
  }),
  opportunity: one(opportunities, {
    fields: [studentOpportunities.opportunityId],
    references: [opportunities.id]
  })
}));
var todoRelations = relations(todos, ({ one }) => ({
  student: one(studentProfiles, {
    fields: [todos.studentId],
    references: [studentProfiles.id]
  })
}));
var chatMessageRelations = relations(chatMessages, ({ one }) => ({
  student: one(studentProfiles, {
    fields: [chatMessages.studentId],
    references: [studentProfiles.id]
  })
}));
var progressTrackingRelations = relations(progressTracking, ({ one }) => ({
  student: one(studentProfiles, {
    fields: [progressTracking.studentId],
    references: [studentProfiles.id]
  })
}));
var achievementRelations = relations(achievements, ({ one }) => ({
  student: one(studentProfiles, {
    fields: [achievements.studentId],
    references: [studentProfiles.id]
  })
}));
var graduationRequirementRelations = relations(graduationRequirements, ({ many }) => ({
  studentProgress: many(studentCourseProgress)
}));
var studentCourseProgressRelations = relations(studentCourseProgress, ({ one }) => ({
  student: one(studentProfiles, {
    fields: [studentCourseProgress.studentId],
    references: [studentProfiles.id]
  }),
  requirement: one(graduationRequirements, {
    fields: [studentCourseProgress.requirementId],
    references: [graduationRequirements.id]
  })
}));
var insertStudentProfileSchema = createInsertSchema(studentProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertTodoSchema = createInsertSchema(todos).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  completedAt: true
});
var insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true
});
var insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertGraduationRequirementSchema = createInsertSchema(graduationRequirements).omit({
  id: true,
  createdAt: true
});
var insertStudentCourseProgressSchema = createInsertSchema(studentCourseProgress).omit({
  id: true,
  createdAt: true
});

// server/db.ts
import { Pool, neonConfig } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-serverless";
import ws from "ws";
neonConfig.webSocketConstructor = ws;
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?"
  );
}
var pool = new Pool({ connectionString: process.env.DATABASE_URL });
var db = drizzle({ client: pool, schema: schema_exports });

// server/storage.ts
import { eq, desc, and } from "drizzle-orm";
var DatabaseStorage = class {
  // User operations (mandatory for Replit Auth)
  async getUser(id) {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  async upsertUser(userData) {
    const [user] = await db.insert(users).values(userData).onConflictDoUpdate({
      target: users.id,
      set: {
        ...userData,
        updatedAt: /* @__PURE__ */ new Date()
      }
    }).returning();
    return user;
  }
  // Student profile operations
  async getStudentProfile(userId) {
    const [profile] = await db.select().from(studentProfiles).where(eq(studentProfiles.userId, userId));
    return profile;
  }
  async createStudentProfile(profile) {
    const [newProfile] = await db.insert(studentProfiles).values(profile).returning();
    return newProfile;
  }
  async updateStudentProfile(id, profile) {
    const [updatedProfile] = await db.update(studentProfiles).set({ ...profile, updatedAt: /* @__PURE__ */ new Date() }).where(eq(studentProfiles.id, id)).returning();
    return updatedProfile;
  }
  // Academic pathway operations
  async getStudentPathway(studentId) {
    const [pathway] = await db.select().from(academicPathways).where(eq(academicPathways.studentId, studentId)).orderBy(desc(academicPathways.lastUpdated)).limit(1);
    return pathway;
  }
  async createOrUpdatePathway(pathway) {
    const existing = await this.getStudentPathway(pathway.studentId);
    if (existing) {
      const [updated] = await db.update(academicPathways).set({ ...pathway, lastUpdated: /* @__PURE__ */ new Date() }).where(eq(academicPathways.id, existing.id)).returning();
      return updated;
    } else {
      const [created] = await db.insert(academicPathways).values(pathway).returning();
      return created;
    }
  }
  // Opportunities operations
  async getOpportunities(filters) {
    let query = db.select().from(opportunities);
    if (filters) {
      const conditions = [];
      if (filters.category) {
        conditions.push(eq(opportunities.category, filters.category));
      }
      if (filters.location) {
        conditions.push(eq(opportunities.location, filters.location));
      }
      if (conditions.length > 0) {
        return await db.select().from(opportunities).where(and(...conditions)).orderBy(desc(opportunities.createdAt));
      }
    }
    return await query.orderBy(desc(opportunities.createdAt));
  }
  async getStudentOpportunities(studentId) {
    const results = await db.select().from(studentOpportunities).innerJoin(opportunities, eq(studentOpportunities.opportunityId, opportunities.id)).where(eq(studentOpportunities.studentId, studentId)).orderBy(desc(studentOpportunities.createdAt));
    return results.map((result) => ({
      ...result.student_opportunities,
      opportunity: result.opportunities
    }));
  }
  async bookmarkOpportunity(studentOpportunity) {
    const [bookmark] = await db.insert(studentOpportunities).values(studentOpportunity).returning();
    return bookmark;
  }
  async updateOpportunityStatus(id, status) {
    const [updated] = await db.update(studentOpportunities).set({ status }).where(eq(studentOpportunities.id, id)).returning();
    return updated;
  }
  // Todo operations
  async getStudentTodos(studentId) {
    return await db.select().from(todos).where(eq(todos.studentId, studentId)).orderBy(desc(todos.createdAt));
  }
  async createTodo(todo) {
    const [newTodo] = await db.insert(todos).values(todo).returning();
    return newTodo;
  }
  async updateTodo(id, updates) {
    const [updated] = await db.update(todos).set({ ...updates, updatedAt: /* @__PURE__ */ new Date() }).where(eq(todos.id, id)).returning();
    return updated;
  }
  async toggleTodoComplete(id) {
    const [todo] = await db.select().from(todos).where(eq(todos.id, id));
    const [updated] = await db.update(todos).set({
      isCompleted: !todo.isCompleted,
      completedAt: todo.isCompleted ? null : /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(todos.id, id)).returning();
    return updated;
  }
  // Chat operations
  async getStudentChatMessages(studentId, limit = 50) {
    return await db.select().from(chatMessages).where(eq(chatMessages.studentId, studentId)).orderBy(desc(chatMessages.createdAt)).limit(limit);
  }
  async createChatMessage(message) {
    const [newMessage] = await db.insert(chatMessages).values(message).returning();
    return newMessage;
  }
  // Progress tracking operations
  async getStudentProgress(studentId) {
    return await db.select().from(progressTracking).where(eq(progressTracking.studentId, studentId)).orderBy(desc(progressTracking.recordedAt));
  }
  async updateProgress(progress) {
    const [newProgress] = await db.insert(progressTracking).values(progress).returning();
    return newProgress;
  }
  // Seed operations
  // Achievement operations
  async getStudentAchievements(studentId) {
    return await db.select().from(achievements).where(eq(achievements.studentId, studentId)).orderBy(desc(achievements.dateAchieved));
  }
  async createAchievement(achievement) {
    const [created] = await db.insert(achievements).values(achievement).returning();
    return created;
  }
  async updateAchievement(id, updates) {
    const [updated] = await db.update(achievements).set({ ...updates, updatedAt: /* @__PURE__ */ new Date() }).where(eq(achievements.id, id)).returning();
    return updated;
  }
  async deleteAchievement(id) {
    await db.delete(achievements).where(eq(achievements.id, id));
  }
  async seedOpportunities() {
    const seedData = [
      {
        title: "NASA Human Rover Competition",
        description: "Perfect for students interested in STEM and engineering. Design and build a human-powered rover to navigate challenging terrain.",
        category: "competition",
        eligibleGrades: [9, 10, 11, 12],
        subjects: ["Engineering", "Physics", "Mathematics"],
        deadline: /* @__PURE__ */ new Date("2024-12-15"),
        applicationUrl: "https://www.nasa.gov/learning/students/",
        isTeamBased: true,
        location: "National",
        isPaid: false,
        difficultyLevel: "intermediate",
        tags: ["STEM", "Engineering", "NASA", "Competition"]
      },
      {
        title: "Congressional App Challenge",
        description: "Create an app that helps solve problems in your community. Open to all high school students.",
        category: "competition",
        eligibleGrades: [9, 10, 11, 12],
        subjects: ["Computer Science", "Programming"],
        deadline: /* @__PURE__ */ new Date("2024-11-01"),
        applicationUrl: "https://www.congressionalappchallenge.us/",
        isTeamBased: false,
        location: "National",
        isPaid: false,
        difficultyLevel: "beginner",
        tags: ["Programming", "App Development", "Congressional"]
      },
      {
        title: "Local Hospital Internship",
        description: "Summer volunteer opportunity at Texas Children's Hospital. Gain hands-on experience in healthcare.",
        category: "internship",
        eligibleGrades: [10, 11, 12],
        subjects: ["Biology", "Medicine", "Health Sciences"],
        deadline: /* @__PURE__ */ new Date("2025-01-15"),
        applicationUrl: "https://www.texaschildrens.org/volunteers",
        isTeamBased: false,
        location: "Houston, TX",
        isPaid: false,
        difficultyLevel: "beginner",
        tags: ["Healthcare", "Medical", "Volunteering", "Local"]
      },
      {
        title: "Science Olympiad",
        description: "National competition covering various science topics from biology to engineering.",
        category: "competition",
        eligibleGrades: [9, 10, 11, 12],
        subjects: ["Biology", "Chemistry", "Physics", "Engineering"],
        deadline: /* @__PURE__ */ new Date("2024-10-30"),
        applicationUrl: "https://www.soinc.org/",
        isTeamBased: true,
        location: "National",
        isPaid: false,
        difficultyLevel: "intermediate",
        tags: ["Science", "Competition", "Team"]
      },
      {
        title: "Math Olympiad (AMC)",
        description: "American Mathematics Competitions - the first step towards International Mathematical Olympiad.",
        category: "competition",
        eligibleGrades: [9, 10, 11, 12],
        subjects: ["Mathematics"],
        deadline: /* @__PURE__ */ new Date("2024-11-15"),
        applicationUrl: "https://www.maa.org/math-competitions",
        isTeamBased: false,
        location: "National",
        isPaid: false,
        difficultyLevel: "advanced",
        tags: ["Mathematics", "Competition", "AMC"]
      },
      {
        title: "Google Code-in for Students",
        description: "Participate in open source projects and contribute to real software development. Great for building your portfolio.",
        category: "internship",
        eligibleGrades: [9, 10, 11, 12],
        subjects: ["Computer Science", "Programming"],
        deadline: /* @__PURE__ */ new Date("2025-02-28"),
        applicationUrl: "https://codein.withgoogle.com/",
        isTeamBased: false,
        location: "Global",
        isPaid: true,
        difficultyLevel: "intermediate",
        tags: ["Programming", "Open Source", "Google"]
      },
      {
        title: "Microsoft TEALS Program",
        description: "High school computer science program bringing tech professionals into classrooms as volunteer teachers.",
        category: "course",
        eligibleGrades: [9, 10, 11, 12],
        subjects: ["Computer Science", "Programming"],
        deadline: /* @__PURE__ */ new Date("2025-03-15"),
        applicationUrl: "https://www.microsoft.com/en-us/teals",
        isTeamBased: false,
        location: "National",
        isPaid: false,
        difficultyLevel: "beginner",
        tags: ["Computer Science", "Microsoft", "Education"]
      },
      {
        title: "Intel International Science Fair",
        description: "The world's largest international pre-college science competition, featuring over 1,800 students.",
        category: "competition",
        eligibleGrades: [9, 10, 11, 12],
        subjects: ["Biology", "Chemistry", "Physics", "Engineering", "Mathematics"],
        deadline: /* @__PURE__ */ new Date("2025-01-15"),
        applicationUrl: "https://www.societyforscience.org/isef/",
        isTeamBased: false,
        location: "International",
        isPaid: false,
        difficultyLevel: "advanced",
        tags: ["Science", "Research", "Intel", "International"]
      },
      {
        title: "NASA USRP Internship",
        description: "Undergraduate Student Research Program offering hands-on research experience with NASA scientists.",
        category: "internship",
        eligibleGrades: [11, 12],
        subjects: ["Physics", "Engineering", "Mathematics", "Computer Science"],
        deadline: /* @__PURE__ */ new Date("2025-01-31"),
        applicationUrl: "https://www.nasa.gov/learning-resources/internship-programs/",
        isTeamBased: false,
        location: "National",
        isPaid: true,
        difficultyLevel: "advanced",
        tags: ["NASA", "Research", "Space", "STEM"]
      },
      {
        title: "Future Business Leaders of America",
        description: "National competition in business skills, leadership, and career preparation for high school students.",
        category: "competition",
        eligibleGrades: [9, 10, 11, 12],
        subjects: ["Business", "Economics", "Leadership"],
        deadline: /* @__PURE__ */ new Date("2025-02-15"),
        applicationUrl: "https://www.fbla.org/",
        isTeamBased: true,
        location: "National",
        isPaid: false,
        difficultyLevel: "intermediate",
        tags: ["Business", "Leadership", "FBLA"]
      },
      {
        title: "MIT Research Science Institute",
        description: "Six-week summer research program pairing high school students with MIT researchers.",
        category: "program",
        eligibleGrades: [11, 12],
        subjects: ["Biology", "Chemistry", "Physics", "Engineering", "Mathematics"],
        deadline: /* @__PURE__ */ new Date("2025-01-10"),
        applicationUrl: "https://www.cee.org/programs/research-science-institute",
        isTeamBased: false,
        location: "Cambridge, MA",
        isPaid: false,
        difficultyLevel: "advanced",
        tags: ["MIT", "Research", "Summer Program", "STEM"]
      },
      {
        title: "Regeneron Science Talent Search",
        description: "Most prestigious science and math competition for high school seniors in the United States.",
        category: "competition",
        eligibleGrades: [12],
        subjects: ["Biology", "Chemistry", "Physics", "Mathematics", "Engineering"],
        deadline: /* @__PURE__ */ new Date("2024-11-15"),
        applicationUrl: "https://www.societyforscience.org/regeneron-sts/",
        isTeamBased: false,
        location: "National",
        isPaid: false,
        difficultyLevel: "advanced",
        tags: ["Science", "Research", "Regeneron", "Prestigious"]
      },
      {
        title: "Program in Mathematics for Young Scientists (PROMYS)",
        description: "6-week program at Boston University for high school sophomores to seniors who love math. Daily Number Theory lectures, research projects, advanced seminars, and guest lecturers.",
        category: "program",
        eligibleGrades: [10, 11, 12],
        subjects: ["Mathematics"],
        deadline: /* @__PURE__ */ new Date("2025-03-05"),
        applicationUrl: "https://promys.org/programs/promys/",
        isTeamBased: false,
        location: "Boston, MA",
        isPaid: false,
        difficultyLevel: "advanced",
        tags: ["Mathematics", "Boston University", "Research", "Summer Program"]
      },
      {
        title: "Canada/USA Math Camp",
        description: "5-week program for students who find beauty in advanced mathematical ideas. Study with world-renowned researchers and passionate students from around the world.",
        category: "program",
        eligibleGrades: [9, 10, 11, 12],
        subjects: ["Mathematics"],
        deadline: /* @__PURE__ */ new Date("2025-03-09"),
        applicationUrl: "https://www.mathcamp.org/",
        isTeamBased: false,
        location: "International",
        isPaid: false,
        difficultyLevel: "advanced",
        tags: ["Mathematics", "International", "Research", "Summer Program"]
      },
      {
        title: "Summer Science Program (SSP)",
        description: "5-week educational experience for high school juniors. 12 research teams work on difficult research projects in astrophysics, biochemistry, and genomics.",
        category: "program",
        eligibleGrades: [11],
        subjects: ["Physics", "Biology", "Chemistry"],
        deadline: /* @__PURE__ */ new Date("2025-03-03"),
        applicationUrl: "https://summerscience.org/",
        isTeamBased: true,
        location: "National",
        isPaid: false,
        difficultyLevel: "advanced",
        tags: ["Science", "Research", "Astrophysics", "Summer Program"]
      },
      {
        title: "Stanford University Math Summer Camp (SUMaC)",
        description: "Advanced math program covering topics like group theory and real-life applications. Available online (3 weeks) or residential (4 weeks).",
        category: "program",
        eligibleGrades: [10, 11],
        subjects: ["Mathematics"],
        deadline: /* @__PURE__ */ new Date("2025-02-01"),
        applicationUrl: "https://spcs.stanford.edu/programs/stanford-university-mathematics-camp-sumac",
        isTeamBased: false,
        location: "Stanford, CA",
        isPaid: false,
        difficultyLevel: "advanced",
        tags: ["Mathematics", "Stanford", "Group Theory", "Summer Program"]
      },
      {
        title: "High School Scientific Training and Enrichment Program (HiSTEP)",
        description: "5-week full-time summer internship at NIH campus covering current health issues, basic science skills, and STEM careers. Includes $2,150 stipend.",
        category: "internship",
        eligibleGrades: [9, 10, 11, 12],
        subjects: ["Biology", "Medicine", "Health Sciences"],
        deadline: /* @__PURE__ */ new Date("2025-02-01"),
        applicationUrl: "https://www.training.nih.gov/histep",
        isTeamBased: false,
        location: "Bethesda, MD",
        isPaid: true,
        difficultyLevel: "intermediate",
        tags: ["Health Sciences", "NIH", "Paid", "Summer Program"]
      },
      {
        title: "Simons Summer Research Program",
        description: "8-week prestigious program matching students with Stony Brook faculty mentors in science, math, and computer science fields. Paid fellowship.",
        category: "program",
        eligibleGrades: [10, 11, 12],
        subjects: ["Biology", "Chemistry", "Physics", "Mathematics", "Computer Science"],
        deadline: /* @__PURE__ */ new Date("2025-02-07"),
        applicationUrl: "https://www.stonybrook.edu/simons/",
        isTeamBased: false,
        location: "Stony Brook, NY",
        isPaid: true,
        difficultyLevel: "advanced",
        tags: ["Research", "Stony Brook", "Fellowship", "Summer Program"]
      },
      {
        title: "Research in Science & Engineering (RISE)",
        description: "6-week, 40-hour program for rising seniors in STEM. Work on research projects with Boston University professors and advisors.",
        category: "program",
        eligibleGrades: [12],
        subjects: ["Biology", "Chemistry", "Physics", "Engineering"],
        deadline: /* @__PURE__ */ new Date("2025-02-14"),
        applicationUrl: "https://www.bu.edu/summer/high-school-programs/rise-internship-practicum/",
        isTeamBased: false,
        location: "Boston, MA",
        isPaid: false,
        difficultyLevel: "advanced",
        tags: ["Research", "Boston University", "Engineering", "Summer Program"]
      },
      {
        title: "Summer Academy for Math and Science (SAMS)",
        description: "Free 5-week engineering program at Carnegie Mellon with symposium. Includes math, science, seminars, and college preparation support.",
        category: "program",
        eligibleGrades: [10, 11, 12],
        subjects: ["Engineering", "Mathematics"],
        deadline: /* @__PURE__ */ new Date("2025-03-09"),
        applicationUrl: "https://www.cmu.edu/pre-college/academic-programs/sams.html",
        isTeamBased: false,
        location: "Pittsburgh, PA",
        isPaid: false,
        difficultyLevel: "intermediate",
        tags: ["Engineering", "Carnegie Mellon", "Free", "Summer Program"]
      },
      {
        title: "HOPP Summer Student Program",
        description: "8-week full-time internship at Memorial Sloan Kettering Cancer Center. Conduct independent biomedical research with $1,200 stipend.",
        category: "internship",
        eligibleGrades: [10, 11, 12],
        subjects: ["Biology", "Medicine", "Health Sciences"],
        deadline: /* @__PURE__ */ new Date("2025-02-07"),
        applicationUrl: "https://www.mskcc.org/education-training/high-school-college/hopp-summer-student",
        isTeamBased: false,
        location: "New York, NY",
        isPaid: true,
        difficultyLevel: "advanced",
        tags: ["Medical Research", "Cancer Research", "Paid", "Summer Program"]
      },
      {
        title: "MITES Summer",
        description: "6-week residential program at MIT for rising seniors from underrepresented communities. Seminars with STEM professionals and lab tours.",
        category: "program",
        eligibleGrades: [12],
        subjects: ["Engineering", "Mathematics", "Physics", "Computer Science"],
        deadline: /* @__PURE__ */ new Date("2025-02-01"),
        applicationUrl: "https://mites.mit.edu/discover-mites/mites-summer/",
        isTeamBased: false,
        location: "Cambridge, MA",
        isPaid: false,
        difficultyLevel: "advanced",
        tags: ["MIT", "Diversity", "Engineering", "Summer Program"]
      },
      {
        title: "Stanford Institutes of Medicine Summer Research Program (SIMR)",
        description: "8-week program for Bay Area students to work with Stanford faculty on medical research. 8 research areas including immunology and neurobiology.",
        category: "program",
        eligibleGrades: [11, 12],
        subjects: ["Biology", "Medicine", "Health Sciences"],
        deadline: /* @__PURE__ */ new Date("2025-02-25"),
        applicationUrl: "https://simr.stanford.edu/",
        isTeamBased: false,
        location: "Stanford, CA",
        isPaid: true,
        difficultyLevel: "advanced",
        tags: ["Stanford", "Medical Research", "Paid", "Summer Program"]
      },
      {
        title: "Telluride Association Summer Seminar (TASS)",
        description: "6-week program focused on history, politics, literature, and art. Examines how power and privilege affect social structures.",
        category: "program",
        eligibleGrades: [10, 11, 12],
        subjects: ["History", "Political Science", "Literature"],
        deadline: /* @__PURE__ */ new Date("2026-01-04"),
        applicationUrl: "https://www.tellurideassociation.org/our-programs/high-school-students/",
        isTeamBased: false,
        location: "National",
        isPaid: false,
        difficultyLevel: "intermediate",
        tags: ["Humanities", "Social Justice", "Free", "Summer Program"]
      },
      {
        title: "Bank of America Student Leaders",
        description: "Leadership development program connecting high school students with nonprofits and includes a week in Washington D.C.",
        category: "program",
        eligibleGrades: [11, 12],
        subjects: ["Leadership", "Business"],
        deadline: /* @__PURE__ */ new Date("2026-01-31"),
        applicationUrl: "https://about.bankofamerica.com/en/making-an-impact/student-leaders",
        isTeamBased: false,
        location: "National",
        isPaid: true,
        difficultyLevel: "intermediate",
        tags: ["Leadership", "Non-profit", "Washington DC", "Summer Program"]
      },
      {
        title: "Microsoft Imagine Cup",
        description: "Premier global technology startup competition for student founders using Microsoft Cloud. Win up to $100,000 USD, mentorship with Microsoft CEO, and global recognition.",
        category: "competition",
        eligibleGrades: [9, 10, 11, 12],
        subjects: ["Computer Science", "Engineering", "Business", "Technology"],
        deadline: /* @__PURE__ */ new Date("2026-01-22"),
        applicationUrl: "https://imaginecup.microsoft.com/en-US/",
        isTeamBased: true,
        location: "Global",
        isPaid: true,
        difficultyLevel: "advanced",
        tags: ["Microsoft", "Startup", "Technology", "Global", "AI", "Cloud"]
      }
    ];
    for (const opportunity of seedData) {
      const existing = await db.select().from(opportunities).where(eq(opportunities.title, opportunity.title)).limit(1);
      if (existing.length === 0) {
        await db.insert(opportunities).values(opportunity);
      }
    }
  }
  // Graduation requirements operations
  async getGraduationRequirements(state) {
    return await db.select().from(graduationRequirements).where(eq(graduationRequirements.state, state)).orderBy(graduationRequirements.subject);
  }
  async getStudentCourseProgress(studentId) {
    return await db.select().from(studentCourseProgress).where(eq(studentCourseProgress.studentId, studentId)).orderBy(studentCourseProgress.createdAt);
  }
  async createStudentCourseProgress(progress) {
    const [created] = await db.insert(studentCourseProgress).values(progress).returning();
    return created;
  }
  async updateStudentCourseProgress(id, updates) {
    const [updated] = await db.update(studentCourseProgress).set(updates).where(eq(studentCourseProgress.id, id)).returning();
    return updated;
  }
};
var storage = new DatabaseStorage();

// server/replitAuth.ts
import * as client from "openid-client";
import { Strategy } from "openid-client/passport";
import passport from "passport";
import session from "express-session";
import memoize from "memoizee";
import connectPg from "connect-pg-simple";
if (!process.env.REPLIT_DOMAINS) {
  throw new Error("Environment variable REPLIT_DOMAINS not provided");
}
if (!process.env.REPL_ID) {
  throw new Error("Environment variable REPL_ID not provided");
}
if (!process.env.SESSION_SECRET) {
  throw new Error("Environment variable SESSION_SECRET not provided");
}
var getOidcConfig = memoize(
  async () => {
    return await client.discovery(
      new URL(process.env.ISSUER_URL ?? "https://replit.com/oidc"),
      process.env.REPL_ID
    );
  },
  { maxAge: 3600 * 1e3 }
);
function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1e3;
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: true,
    ttl: sessionTtl,
    tableName: "sessions"
  });
  return session({
    secret: process.env.SESSION_SECRET,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: sessionTtl
    }
  });
}
function updateUserSession(user, tokens) {
  user.claims = tokens.claims();
  user.access_token = tokens.access_token;
  user.refresh_token = tokens.refresh_token;
  user.expires_at = user.claims?.exp;
}
async function upsertUser(claims) {
  await storage.upsertUser({
    id: claims["sub"],
    email: claims["email"],
    firstName: claims["first_name"],
    lastName: claims["last_name"],
    profileImageUrl: claims["profile_image_url"]
  });
}
async function setupAuth(app2) {
  app2.set("trust proxy", 1);
  app2.use(getSession());
  app2.use(passport.initialize());
  app2.use(passport.session());
  const config = await getOidcConfig();
  const verify = async (tokens, verified) => {
    const user = {};
    updateUserSession(user, tokens);
    await upsertUser(tokens.claims());
    verified(null, user);
  };
  for (const domain of process.env.REPLIT_DOMAINS.split(",")) {
    const strategy = new Strategy(
      {
        name: `replitauth:${domain}`,
        config,
        scope: "openid email profile offline_access",
        callbackURL: `https://${domain}/api/callback`
      },
      verify
    );
    passport.use(strategy);
  }
  passport.serializeUser((user, cb) => cb(null, user));
  passport.deserializeUser((user, cb) => cb(null, user));
  app2.get("/api/login", (req, res, next) => {
    passport.authenticate(`replitauth:${req.hostname}`, {
      prompt: "login consent",
      scope: ["openid", "email", "profile", "offline_access"]
    })(req, res, next);
  });
  app2.get("/api/callback", (req, res, next) => {
    passport.authenticate(`replitauth:${req.hostname}`, {
      successReturnToOrRedirect: "/",
      failureRedirect: "/api/login"
    })(req, res, next);
  });
  app2.get("/api/logout", (req, res) => {
    req.logout(() => {
      res.redirect(
        client.buildEndSessionUrl(config, {
          client_id: process.env.REPL_ID,
          post_logout_redirect_uri: `${req.protocol}://${req.hostname}`
        }).href
      );
    });
  });
}
var isAuthenticated = async (req, res, next) => {
  const user = req.user;
  if (!req.isAuthenticated() || !user.expires_at) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  const now = Math.floor(Date.now() / 1e3);
  if (now <= user.expires_at) {
    return next();
  }
  const refreshToken = user.refresh_token;
  if (!refreshToken) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }
  try {
    const config = await getOidcConfig();
    const tokenResponse = await client.refreshTokenGrant(config, refreshToken);
    updateUserSession(user, tokenResponse);
    return next();
  } catch (error) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }
};

// server/services/pathwayGenerator.ts
import OpenAI from "openai";
var openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});
async function generateAcademicPathway(studentProfile) {
  try {
    const prompt = `Generate a comprehensive 4-year academic pathway for a student with the following profile:

Current Grade: ${studentProfile.currentGrade}
Current GPA: ${studentProfile.currentGpa || "Not provided"}
Dream Colleges: ${studentProfile.dreamColleges?.join(", ") || "Top Universities"}
Academic Interests: ${studentProfile.academicInterests?.join(", ") || "General"}
Career Goals: ${studentProfile.careerGoals || "Not specified"}
Current Subjects: ${studentProfile.currentSubjects?.join(", ") || "Standard curriculum"}
Interested Subjects: ${studentProfile.interestedSubjects?.join(", ") || "Various"}
Location: ${studentProfile.location || "Not specified"}
School District: ${studentProfile.schoolDistrict || "Not specified"}

Create a detailed academic pathway with specific, actionable tasks for each grade level (9-12). Each grade should include:
- Core academic courses (including specific AP/IB recommendations)
- Extracurricular activities and leadership opportunities
- Competitions and contests relevant to their interests
- Test preparation milestones
- Summer activities (internships, programs, etc.)
- Volunteer work and community service
- Research projects or independent studies
- Skills development activities

Provide realistic, achievable goals that build upon each other and align with their dream colleges and career interests.

Respond with JSON in this exact format:
{
  "grade9": [
    {
      "title": "Course/Activity Name",
      "category": "academic|extracurricular|competition|volunteer|summer|test_prep",
      "description": "Detailed description",
      "timeline": "When to complete (e.g., Fall, Spring, Summer)",
      "priority": "high|medium|low",
      "status": "completed|in_progress|not_started"
    }
  ],
  "grade10": [...],
  "grade11": [...],
  "grade12": [...]
}`;
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.4
    });
    const pathwayData = JSON.parse(response.choices[0].message.content || "{}");
    const grades = ["grade9", "grade10", "grade11", "grade12"];
    const validatedPathway = {};
    for (const grade of grades) {
      validatedPathway[grade] = Array.isArray(pathwayData[grade]) ? pathwayData[grade] : [];
    }
    return validatedPathway;
  } catch (error) {
    console.error("Error generating academic pathway:", error);
    return {
      grade9: [
        {
          title: "Build Strong Academic Foundation",
          category: "academic",
          description: "Focus on core subjects and maintain high GPA",
          timeline: "Year-round",
          priority: "high",
          status: "in_progress"
        },
        {
          title: "Join Academic Clubs",
          category: "extracurricular",
          description: "Participate in Math, Science, or relevant subject clubs",
          timeline: "Fall",
          priority: "medium",
          status: "not_started"
        }
      ],
      grade10: [
        {
          title: "Take First AP Course",
          category: "academic",
          description: "Enroll in AP course aligned with interests",
          timeline: "Year-round",
          priority: "high",
          status: "not_started"
        },
        {
          title: "PSAT Preparation",
          category: "test_prep",
          description: "Begin standardized test preparation",
          timeline: "Spring",
          priority: "medium",
          status: "not_started"
        }
      ],
      grade11: [
        {
          title: "Advanced Course Load",
          category: "academic",
          description: "Take multiple AP/IB courses",
          timeline: "Year-round",
          priority: "high",
          status: "not_started"
        },
        {
          title: "SAT/ACT Preparation",
          category: "test_prep",
          description: "Intensive test preparation and taking",
          timeline: "Fall/Spring",
          priority: "high",
          status: "not_started"
        }
      ],
      grade12: [
        {
          title: "College Applications",
          category: "academic",
          description: "Complete and submit college applications",
          timeline: "Fall",
          priority: "high",
          status: "not_started"
        },
        {
          title: "Final Transcript",
          category: "academic",
          description: "Maintain strong grades through graduation",
          timeline: "Year-round",
          priority: "high",
          status: "not_started"
        }
      ]
    };
  }
}

// server/services/openai.ts
import OpenAI2 from "openai";
var openai2 = new OpenAI2({
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});
async function getChatResponse(message, studentProfile) {
  try {
    const systemPrompt = `You are AIMS (Artificial Intelligence Mentor for Students), a specialized AI academic mentor designed exclusively to guide high school students towards their dream colleges and academic success.

IMPORTANT: You are strictly an EDUCATIONAL chatbot. Only respond to questions related to:
- Academic planning and coursework
- College preparation and admissions
- Educational opportunities and competitions
- Study strategies and test preparation
- Career guidance related to education
- Extracurricular activities for academic growth
- Scholarship and financial aid for education

If a user asks about topics unrelated to education (entertainment, personal life, general topics, etc.), respond with:
"I'm an educational AI mentor focused solely on helping students with their academic journey. I'd be happy to help you with questions about college preparation, course selection, study strategies, academic opportunities, or any other education-related topics. What educational question can I assist you with today?"

Student Profile:
- Name: Student (Grade ${studentProfile.currentGrade})
- Current GPA: ${studentProfile.currentGpa || "Not provided"}
- Dream Colleges: ${studentProfile.dreamColleges?.join(", ") || "Not specified"}
- Academic Interests: ${studentProfile.academicInterests?.join(", ") || "Not specified"}
- Career Goals: ${studentProfile.careerGoals || "Not specified"}
- Current Subjects: ${studentProfile.currentSubjects?.join(", ") || "Not specified"}
- Interested Subjects: ${studentProfile.interestedSubjects?.join(", ") || "Not specified"}

Your educational role includes:
1. Provide personalized academic guidance based on their profile
2. Suggest relevant educational opportunities, competitions, and courses
3. Help with college preparation strategies
4. Motivate and encourage academic growth
5. Answer questions about academic pathways and extracurriculars
6. Offer study tips and test preparation advice

Response formatting guidelines:
- Use proper markdown formatting with **bold** for emphasis and bullet points for lists
- Structure responses with clear sections using line breaks
- Include numbered steps for action items
- Use bullet points (\u2022) for key recommendations
- Format examples with proper indentation
- Keep paragraphs concise but informative

Be encouraging, specific, and actionable in your educational responses. Always format your responses professionally with clear structure and proper indentation.`;
    const response = await openai2.chat.completions.create({
      model: "gpt-4o",
      // Current model - change this to: "gpt-4o-mini", "gpt-4-turbo", "gpt-4", or "gpt-3.5-turbo"
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      max_tokens: 800,
      temperature: 0.7
    });
    return response.choices[0].message.content || "I apologize, but I couldn't generate a response. Please try asking your question again.";
  } catch (error) {
    console.error("Error getting chat response:", error);
    return "I'm having trouble connecting right now. Please try again in a moment.";
  }
}

// server/routes.ts
async function registerRoutes(app2) {
  await setupAuth(app2);
  app2.get("/api/auth/user", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  app2.get("/api/student/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      res.json(profile);
    } catch (error) {
      console.error("Error fetching student profile:", error);
      res.status(500).json({ message: "Failed to fetch student profile" });
    }
  });
  app2.post("/api/student/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const {
        currentSubjects,
        interestedSubjects,
        dreamColleges,
        academicInterests,
        extracurricularActivities,
        completedAPs,
        plannedAPs,
        ...otherFields
      } = req.body;
      const profileData = {
        ...otherFields,
        userId,
        isOnboardingComplete: true,
        currentSubjects: Array.isArray(currentSubjects) ? currentSubjects : [],
        interestedSubjects: Array.isArray(interestedSubjects) ? interestedSubjects : [],
        dreamColleges: Array.isArray(dreamColleges) ? dreamColleges : [],
        academicInterests: Array.isArray(academicInterests) ? academicInterests : [],
        extracurricularActivities: Array.isArray(extracurricularActivities) ? extracurricularActivities : [],
        completedAPs: Array.isArray(completedAPs) ? completedAPs : [],
        plannedAPs: Array.isArray(plannedAPs) ? plannedAPs : []
      };
      const validatedData = insertStudentProfileSchema.parse(profileData);
      const profile = await storage.createStudentProfile(validatedData);
      if (profile.dreamColleges && profile.dreamColleges.length > 0) {
        const pathwayData = await generateAcademicPathway(profile);
        await storage.createOrUpdatePathway({
          studentId: profile.id,
          pathwayData,
          targetCollege: profile.dreamColleges[0],
          overallProgress: "0"
        });
      }
      res.json(profile);
    } catch (error) {
      console.error("Error creating student profile:", error);
      res.status(400).json({
        message: "Failed to create student profile",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  app2.put("/api/student/profile/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const profile = await storage.updateStudentProfile(parseInt(id), updates);
      res.json(profile);
    } catch (error) {
      console.error("Error updating student profile:", error);
      res.status(400).json({ message: "Failed to update student profile" });
    }
  });
  app2.get("/api/student/pathway", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const pathway = await storage.getStudentPathway(profile.id);
      res.json(pathway);
    } catch (error) {
      console.error("Error fetching pathway:", error);
      res.status(500).json({ message: "Failed to fetch pathway" });
    }
  });
  app2.post("/api/student/pathway/regenerate", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const pathwayData = await generateAcademicPathway(profile);
      const pathway = await storage.createOrUpdatePathway({
        studentId: profile.id,
        pathwayData,
        targetCollege: profile.dreamColleges?.[0] || "Top University",
        overallProgress: "0"
      });
      res.json(pathway);
    } catch (error) {
      console.error("Error regenerating pathway:", error);
      res.status(500).json({ message: "Failed to regenerate pathway" });
    }
  });
  app2.get("/api/opportunities", isAuthenticated, async (req, res) => {
    try {
      const { grades, subjects, category, location, recommended } = req.query;
      const filters = {
        grades: grades ? grades.split(",").map(Number) : void 0,
        subjects: subjects ? subjects.split(",") : void 0,
        category,
        location
      };
      const opportunities2 = await storage.getOpportunities(filters);
      if (recommended === "true") {
        const userId = req.user.claims.sub;
        const studentProfile = await storage.getStudentProfile(userId);
        if (studentProfile) {
          const { matchOpportunities: matchOpportunities2 } = await Promise.resolve().then(() => (init_opportunityMatcher(), opportunityMatcher_exports));
          const matches = matchOpportunities2(studentProfile, opportunities2);
          res.json(matches.map((match) => ({
            ...match.opportunity,
            matchScore: match.score,
            matchReasons: match.reasons
          })));
          return;
        }
      }
      res.json(opportunities2);
    } catch (error) {
      console.error("Error fetching opportunities:", error);
      res.status(500).json({ message: "Failed to fetch opportunities" });
    }
  });
  app2.get("/api/student/opportunities", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const opportunities2 = await storage.getStudentOpportunities(profile.id);
      res.json(opportunities2);
    } catch (error) {
      console.error("Error fetching student opportunities:", error);
      res.status(500).json({ message: "Failed to fetch student opportunities" });
    }
  });
  app2.post("/api/student/opportunities/:opportunityId/bookmark", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { opportunityId } = req.params;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const bookmark = await storage.bookmarkOpportunity({
        studentId: profile.id,
        opportunityId: parseInt(opportunityId),
        status: "bookmarked"
      });
      res.json(bookmark);
    } catch (error) {
      console.error("Error bookmarking opportunity:", error);
      res.status(400).json({ message: "Failed to bookmark opportunity" });
    }
  });
  app2.get("/api/student/recommended-opportunities", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const studentProfile = await storage.getStudentProfile(userId);
      if (!studentProfile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const allOpportunities = await storage.getOpportunities({});
      const { matchOpportunities: matchOpportunities2, getUpcomingOpportunities: getUpcomingOpportunities2 } = await Promise.resolve().then(() => (init_opportunityMatcher(), opportunityMatcher_exports));
      const matches = matchOpportunities2(studentProfile, allOpportunities);
      const upcoming = getUpcomingOpportunities2(allOpportunities);
      res.json({
        recommended: matches.slice(0, 6).map((match) => ({
          ...match.opportunity,
          matchScore: match.score,
          matchReasons: match.reasons
        })),
        upcoming,
        totalMatches: matches.length
      });
    } catch (error) {
      console.error("Error fetching recommended opportunities:", error);
      res.status(500).json({ message: "Failed to fetch recommended opportunities" });
    }
  });
  app2.get("/api/student/todos", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const todos2 = await storage.getStudentTodos(profile.id);
      res.json(todos2);
    } catch (error) {
      console.error("Error fetching todos:", error);
      res.status(500).json({ message: "Failed to fetch todos" });
    }
  });
  app2.post("/api/student/todos", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      console.log("Creating todo for user:", userId);
      console.log("Request body:", req.body);
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        console.log("Student profile not found for user:", userId);
        return res.status(404).json({ message: "Student profile not found" });
      }
      console.log("Found profile:", profile.id);
      const todoData = {
        ...req.body,
        studentId: profile.id,
        // Convert string date to Date object if provided
        dueDate: req.body.dueDate ? new Date(req.body.dueDate) : null
      };
      console.log("Todo data before validation:", todoData);
      const validatedData = insertTodoSchema.parse(todoData);
      console.log("Validated data:", validatedData);
      const todo = await storage.createTodo(validatedData);
      console.log("Created todo:", todo);
      res.json(todo);
    } catch (error) {
      console.error("Error creating todo:", error);
      if (error instanceof Error) {
        console.error("Error message:", error.message);
        console.error("Error stack:", error.stack);
      }
      res.status(400).json({
        message: "Failed to create todo",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });
  app2.put("/api/student/todos/:id/toggle", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const todo = await storage.toggleTodoComplete(parseInt(id));
      res.json(todo);
    } catch (error) {
      console.error("Error toggling todo:", error);
      res.status(400).json({ message: "Failed to toggle todo" });
    }
  });
  app2.get("/api/student/chat", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const messages = await storage.getStudentChatMessages(profile.id);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });
  app2.post("/api/student/chat", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const { message } = req.body;
      const userMessage = await storage.createChatMessage({
        studentId: profile.id,
        message,
        sender: "user"
      });
      const aiResponse = await getChatResponse(message, profile);
      const aiMessage = await storage.createChatMessage({
        studentId: profile.id,
        message: aiResponse,
        sender: "ai"
      });
      res.json({ userMessage, aiMessage });
    } catch (error) {
      console.error("Error processing chat message:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });
  app2.get("/api/student/graduation-requirements", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const requirements = await storage.getGraduationRequirements(profile.state || "California");
      const progress = await storage.getStudentCourseProgress(profile.id);
      res.json({ requirements, progress });
    } catch (error) {
      console.error("Error fetching graduation requirements:", error);
      res.status(500).json({ message: "Failed to fetch graduation requirements" });
    }
  });
  app2.post("/api/student/course-progress", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const progressData = {
        ...req.body,
        studentId: profile.id
      };
      const validatedData = insertStudentCourseProgressSchema.parse(progressData);
      const progress = await storage.createStudentCourseProgress(validatedData);
      res.json(progress);
    } catch (error) {
      console.error("Error creating course progress:", error);
      res.status(400).json({ message: "Failed to create course progress" });
    }
  });
  app2.put("/api/student/course-progress/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const progress = await storage.updateStudentCourseProgress(parseInt(id), req.body);
      res.json(progress);
    } catch (error) {
      console.error("Error updating course progress:", error);
      res.status(400).json({ message: "Failed to update course progress" });
    }
  });
  app2.patch("/api/auth/user", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { firstName, lastName } = req.body;
      const updatedUser = await storage.upsertUser({
        id: userId,
        firstName,
        lastName,
        email: req.user.claims.email,
        profileImageUrl: req.user.claims.picture
      });
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });
  app2.get("/api/student/progress", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const progress = await storage.getStudentProgress(profile.id);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching progress:", error);
      res.status(500).json({ message: "Failed to fetch progress" });
    }
  });
  app2.get("/api/student/achievements", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const achievements2 = await storage.getStudentAchievements(profile.id);
      res.json(achievements2);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });
  app2.post("/api/student/achievements", isAuthenticated, async (req, res) => {
    try {
      console.log("Creating achievement for user:", req.user.claims.sub);
      console.log("Request body:", req.body);
      const userId = req.user.claims.sub;
      const profile = await storage.getStudentProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      const achievementData = {
        ...req.body,
        studentId: profile.id,
        dateAchieved: req.body.dateAchieved ? new Date(req.body.dateAchieved) : null,
        skills: Array.isArray(req.body.skills) ? req.body.skills : []
      };
      console.log("Achievement data before validation:", achievementData);
      const validatedData = insertAchievementSchema.parse(achievementData);
      console.log("Validated data:", validatedData);
      const achievement = await storage.createAchievement(validatedData);
      console.log("Created achievement:", achievement);
      res.json(achievement);
    } catch (error) {
      console.error("Error creating achievement:", error);
      res.status(500).json({ message: "Failed to create achievement" });
    }
  });
  app2.patch("/api/student/achievements/:id", isAuthenticated, async (req, res) => {
    try {
      const achievementId = parseInt(req.params.id);
      const updates = {
        ...req.body,
        dateAchieved: req.body.dateAchieved ? new Date(req.body.dateAchieved) : void 0,
        skills: Array.isArray(req.body.skills) ? req.body.skills : void 0
      };
      const achievement = await storage.updateAchievement(achievementId, updates);
      res.json(achievement);
    } catch (error) {
      console.error("Error updating achievement:", error);
      res.status(500).json({ message: "Failed to update achievement" });
    }
  });
  app2.delete("/api/student/achievements/:id", isAuthenticated, async (req, res) => {
    try {
      const achievementId = parseInt(req.params.id);
      await storage.deleteAchievement(achievementId);
      res.json({ message: "Achievement deleted successfully" });
    } catch (error) {
      console.error("Error deleting achievement:", error);
      res.status(500).json({ message: "Failed to delete achievement" });
    }
  });
  app2.get("/api/opportunities", async (req, res) => {
    try {
      const opportunities2 = await storage.getOpportunities();
      res.json(opportunities2);
    } catch (error) {
      console.error("Error fetching opportunities:", error);
      res.status(500).json({ message: "Failed to fetch opportunities" });
    }
  });
  app2.post("/api/seed/opportunities", async (req, res) => {
    try {
      await storage.seedOpportunities();
      res.json({ message: "Opportunities seeded successfully" });
    } catch (error) {
      console.error("Error seeding opportunities:", error);
      res.status(500).json({ message: "Failed to seed opportunities" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/index.ts
if (process.env.NODE_ENV === "production") {
  const requiredEnvVars = [
    "DATABASE_URL",
    "REPLIT_DOMAINS",
    "REPL_ID",
    "SESSION_SECRET"
  ];
  const missingVars = requiredEnvVars.filter((varName) => !process.env[varName]);
  if (missingVars.length > 0) {
    console.error("\u274C Missing required environment variables for production:");
    missingVars.forEach((varName) => {
      console.error(`   - ${varName}`);
    });
    console.error("\nApplication cannot start without these environment variables.");
    process.exit(1);
  }
  console.log("\u2713 All required environment variables are present");
}
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = 5e3;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
